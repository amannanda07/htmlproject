<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title></title>
    <style>
      @import url("/Users/amannanda/Desktop/project2/css/styles.css");
    </style>
  </head>
  <body class="pro">
    <!-- pager is the product i choose -->
    <!-- heading -->
    <!-- header-->
    <h1>
      Motorola TalkAbout 2Way Pager - Pagewriter / Timeport Functional Powers On
    </h1>

    <ul>
    <li><a href="/Users/amannanda/Desktop/project2/index.html">Home</a></li>
    <li><a href="/Users/amannanda/Desktop/project2/about.html">About</a></li>
    <li><a href="/Users/amannanda/Desktop/project2/info.html">Company Information</a></li>
    <li><a href="/Users/amannanda/Desktop/project2/promotion.html">Promotion</a></li>
    <li><a href="/Users/amannanda/Desktop/project2/rate.html">Rating and Review </a></li>
    <li><a href="/Users/amannanda/Desktop/project2/support.html">Support</a></li>
    </ul>
  </header>


    <!-- inserted image -->
    <img src="/Users/amannanda/Desktop/project2/images/pager-elite_med.png" alt="Motorola pager" class="center">


  <!-- main -->
  <main class="just">
    <h2 class="promo">Promotional Video:</h2>
    <p class="less"><a href="https://www.youtube.com/watch?v=V9dxWf0yoj4">Video</a></p>


    <!-- about promotions -->
    <p>

    </p>
  </main>





    <!-- footer -->
    <footer>
      <small>
        All rights reserved | Aman Nanda
      </small>
    </footer>

  </body>
</html>
